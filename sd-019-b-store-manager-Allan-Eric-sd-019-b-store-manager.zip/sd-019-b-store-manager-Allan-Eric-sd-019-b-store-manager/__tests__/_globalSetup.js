const { runMigration } = require('./_utils')

module.exports = async () => {
  await runMigration()
}